package elevatorFunctions;

public interface State {
	
	public void pushFloorOneButton();
	public void pushFloorTwoButton();
	public void pushFloorThreeButton();
}